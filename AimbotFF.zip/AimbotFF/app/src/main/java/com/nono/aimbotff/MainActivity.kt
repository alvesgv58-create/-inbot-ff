package com.nono.aimbotff

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val PROJECTION_CODE = 101
    private val OVERLAY_CODE = 102
    private lateinit var projManager: MediaProjectionManager
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        statusText = findViewById(R.id.tvStatus)

        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_CODE)
        }

        findViewById<Button>(R.id.btnAcessibilidade).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Ativa NoneApp na lista de acessibilidade", Toast.LENGTH_LONG).show()
        }

        findViewById<Switch>(R.id.switchAimbot).setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                startActivityForResult(
                    projManager.createScreenCaptureIntent(),
                    PROJECTION_CODE
                )
            } else {
                AimbotService.getInstance()?.stopAimbot()
                statusText.text = "Status: OFF 🔴"
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == PROJECTION_CODE && resultCode == RESULT_OK && data != null) {
            val metrics = resources.displayMetrics
            AimbotService.projectionResultCode = resultCode
            AimbotService.projectionData = data
            AimbotService.screenW = metrics.widthPixels
            AimbotService.screenH = metrics.heightPixels

            val intent = Intent(this, AimbotService::class.java)
            startService(intent)

            statusText.text = "Status: ON 🟢"
            Toast.makeText(this, "[Nono] Aimbot ligado", Toast.LENGTH_SHORT).show()
        }
    }
}
