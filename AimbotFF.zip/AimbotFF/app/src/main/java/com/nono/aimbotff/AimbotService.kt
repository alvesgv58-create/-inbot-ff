package com.nono.aimbotff

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class AimbotService : AccessibilityService() {

    companion object {
        var projectionResultCode: Int = 0
        var projectionData: Intent? = null
        var screenW: Int = 1080
        var screenH: Int = 1920
        private var instance: AimbotService? = null
        fun getInstance() = instance
    }

    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var running = false
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Cor da barra de vida inimigo — vermelho FF
    private val R_MIN = 180; private val R_MAX = 255
    private val G_MIN = 0;   private val G_MAX = 80
    private val B_MIN = 0;   private val B_MAX = 80

    // Suavizacao aim
    private var lastX = -1f
    private var lastY = -1f
    private val SMOOTH = 0.65f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        startForegroundNotification()
    }

    fun stopAimbot() {
        running = false
        scope.cancel()
        virtualDisplay?.release()
        mediaProjection?.stop()
        imageReader?.close()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        initProjection()
        return START_STICKY
    }

    private fun initProjection() {
        val data = projectionData ?: return
        val projManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projManager.getMediaProjection(projectionResultCode, data)

        imageReader = ImageReader.newInstance(
            screenW, screenH,
            PixelFormat.RGBA_8888, 2
        )

        virtualDisplay = mediaProjection!!.createVirtualDisplay(
            "AimbotCapture",
            screenW, screenH,
            resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null
        )

        running = true
        scope.launch { aimbotLoop() }
    }

    private suspend fun aimbotLoop() {
        while (running) {
            val bmp = captureScreen()
            if (bmp != null) {
                val target = findTarget(bmp)
                if (target != null) {
                    val tx = if (lastX < 0) target.first.toFloat()
                              else lastX + (target.first - lastX) * SMOOTH
                    val ty = if (lastY < 0) target.second.toFloat()
                              else lastY + (target.second - lastY) * SMOOTH
                    lastX = tx
                    lastY = ty
                    performTap(tx, ty)
                } else {
                    lastX = -1f
                    lastY = -1f
                }
                bmp.recycle()
            }
            delay(100)
        }
    }

    private fun captureScreen(): Bitmap? {
        return try {
            val image = imageReader?.acquireLatestImage() ?: return null
            val plane = image.planes[0]
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val rowPadding = rowStride - pixelStride * image.width

            val bmp = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bmp.copyPixelsFromBuffer(buffer)
            image.close()
            bmp
        } catch (e: Exception) { null }
    }

    private fun findTarget(bmp: Bitmap): Pair<Int, Int>? {
        val w = bmp.width
        val h = bmp.height

        val x0 = w / 4;  val x1 = w * 3 / 4
        val y0 = h / 6;  val y1 = h * 5 / 6

        var bestX = -1; var bestY = -1
        var bestDist = Int.MAX_VALUE

        for (y in y0 until y1 step 5) {
            for (x in x0 until x1 step 5) {
                val pixel = bmp.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF

                if (r in R_MIN..R_MAX &&
                    g in G_MIN..G_MAX &&
                    b in B_MIN..B_MAX) {
                    val dist = Math.abs(x - w / 2) + Math.abs(y - h / 2)
                    if (dist < bestDist) {
                        bestDist = dist
                        bestX = x
                        bestY = y
                    }
                }
            }
        }

        return if (bestX != -1) Pair(bestX, bestY) else null
    }

    private fun performTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun startForegroundNotification() {
        val channelId = "aimbot_ch"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "NoneApp", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setContentTitle("NoneApp")
            .setContentText("Rodando em background...")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, notif)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAimbot() }
    override fun onDestroy() {
        stopAimbot()
        instance = null
        super.onDestroy()
    }
}
