package com.nono.aimbotff

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayManager(private val context: Context) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: TextView? = null

    fun show(text: String) {
        if (overlayView != null) {
            overlayView?.text = text
            return
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 10; y = 10
        }
        overlayView = TextView(context).apply {
            this.text = text
            setTextColor(Color.RED)
            textSize = 14f
            setBackgroundColor(Color.argb(120, 0, 0, 0))
            setPadding(8, 4, 8, 4)
        }
        wm.addView(overlayView, params)
    }

    fun hide() {
        overlayView?.let { wm.removeView(it) }
        overlayView = null
    }
}
